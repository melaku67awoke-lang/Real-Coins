package com.example.data.model

import androidx.compose.ui.graphics.Color

/**
 * Deposit-volume levels and daily REAL rewards.
 *
 * Users below the first threshold still receive the platform-wide base reward
 * of 10 REAL every 24 hours. Level upgrades are based on cumulative approved
 * deposit volume (USD).
 */
enum class UserLevelTier(
    val levelName: String,
    val minDepositUsd: Double,
    val dailyRewardReal: Double,
    val multiplier: Double,
    val multiplierDisplay: String,
    val badgeColor: Color,
    val gradientStart: Color,
    val gradientEnd: Color,
    val perks: List<String>
) {
    STARTER(
        levelName = "Starter",
        minDepositUsd = 100.0,
        dailyRewardReal = 30.0,
        multiplier = 3.0,
        multiplierDisplay = "3.0x",
        badgeColor = Color(0xFF38BDF8),
        gradientStart = Color(0xFF0284C7),
        gradientEnd = Color(0xFF075985),
        perks = listOf(
            "30 Real coin daily reward per day",
            "Full P2P Escrow Trading Access",
            "Standard community chat and live broadcasting"
        )
    ),
    SILVER(
        levelName = "Silver",
        minDepositUsd = 150.0,
        dailyRewardReal = 50.0,
        multiplier = 5.0,
        multiplierDisplay = "5.0x",
        badgeColor = Color(0xFFE2E8F0),
        gradientStart = Color(0xFF94A3B8),
        gradientEnd = Color(0xFF475569),
        perks = listOf(
            "50 Real coin daily reward per day",
            "Higher P2P buying and selling order limits",
            "Silver verified trader profile badge"
        )
    ),
    BRONZE(
        levelName = "Bronze",
        minDepositUsd = 200.0,
        dailyRewardReal = 75.0,
        multiplier = 7.5,
        multiplierDisplay = "7.5x",
        badgeColor = Color(0xFFCD7F32),
        gradientStart = Color(0xFFB45309),
        gradientEnd = Color(0xFF78350F),
        perks = listOf(
            "75 Real coin daily reward per day",
            "Higher P2P trading limits",
            "Bronze verified trader profile badge"
        )
    ),
    GOLD(
        levelName = "Gold",
        minDepositUsd = 250.0,
        dailyRewardReal = 100.0,
        multiplier = 10.0,
        multiplierDisplay = "10.0x",
        badgeColor = Color(0xFFFBBF24),
        gradientStart = Color(0xFFF59E0B),
        gradientEnd = Color(0xFF92400E),
        perks = listOf(
            "100 Real coin daily reward per day",
            "Priority admin deposit verification queue",
            "Gold verified badge on P2P adverts"
        )
    ),
    DIAMOND(
        levelName = "Diamond",
        minDepositUsd = 300.0,
        dailyRewardReal = 150.0,
        multiplier = 15.0,
        multiplierDisplay = "15.0x",
        badgeColor = Color(0xFFA78BFA),
        gradientStart = Color(0xFF8B5CF6),
        gradientEnd = Color(0xFF5B21B6),
        perks = listOf(
            "150 Real coin daily reward per day",
            "Highest configured P2P order limits",
            "Diamond crown avatar frame and VIP creator privileges"
        )
    );

    companion object {
        const val BASE_DAILY_REWARD_REAL = 10.0
        val ALL_TIERS = entries.toList()

        fun getTierForDeposit(totalUsdt: Double): UserLevelTier {
            return when {
                totalUsdt >= DIAMOND.minDepositUsd -> DIAMOND
                totalUsdt >= GOLD.minDepositUsd -> GOLD
                totalUsdt >= BRONZE.minDepositUsd -> BRONZE
                totalUsdt >= SILVER.minDepositUsd -> SILVER
                totalUsdt >= STARTER.minDepositUsd -> STARTER
                else -> STARTER
            }
        }

        fun getNextTier(currentTier: UserLevelTier): UserLevelTier? {
            val idx = entries.indexOf(currentTier)
            return if (idx < entries.size - 1) entries[idx + 1] else null
        }

        fun getDailyRewardForDeposit(totalUsdt: Double): Double {
            return if (totalUsdt >= STARTER.minDepositUsd) {
                getTierForDeposit(totalUsdt).dailyRewardReal
            } else {
                BASE_DAILY_REWARD_REAL
            }
        }

        fun calculateProgress(totalDepositUsdt: Double): UserLevelProgress {
            val belowStarter = totalDepositUsdt < STARTER.minDepositUsd
            val currentTier = getTierForDeposit(totalDepositUsdt)
            val nextTier = if (belowStarter) STARTER else getNextTier(currentTier)
            val currentTierBaseDeposit = if (belowStarter) 0.0 else currentTier.minDepositUsd
            val nextTierTargetDeposit = nextTier?.minDepositUsd ?: DIAMOND.minDepositUsd

            val progressToNext = if (nextTier == null) {
                1.0f
            } else {
                val span = nextTierTargetDeposit - currentTierBaseDeposit
                val inSpan = (totalDepositUsdt - currentTierBaseDeposit).coerceAtLeast(0.0)
                if (span > 0.0) (inSpan / span).toFloat().coerceIn(0f, 1f) else 1f
            }

            val amountNeeded = if (nextTier == null) {
                0.0
            } else {
                (nextTierTargetDeposit - totalDepositUsdt).coerceAtLeast(0.0)
            }

            return UserLevelProgress(
                currentTier = currentTier,
                nextTier = nextTier,
                isStarterUnlocked = !belowStarter,
                totalDepositUsd = totalDepositUsdt,
                currentTierBaseDeposit = currentTierBaseDeposit,
                nextTierTargetDeposit = nextTierTargetDeposit,
                progressToNextTier = progressToNext,
                amountNeededForNextTier = amountNeeded,
                overallVipProgress = (totalDepositUsdt / DIAMOND.minDepositUsd).toFloat().coerceIn(0f, 1f),
                dailyRewardReal = getDailyRewardForDeposit(totalDepositUsdt),
                rewardMultiplier = if (belowStarter) 1.0 else currentTier.multiplier,
                rewardMultiplierDisplay = if (belowStarter) "1.0x" else currentTier.multiplierDisplay
            )
        }
    }
}

data class UserLevelProgress(
    val currentTier: UserLevelTier,
    val nextTier: UserLevelTier?,
    val isStarterUnlocked: Boolean,
    val totalDepositUsd: Double,
    val currentTierBaseDeposit: Double,
    val nextTierTargetDeposit: Double,
    val progressToNextTier: Float,
    val amountNeededForNextTier: Double,
    val overallVipProgress: Float,
    val dailyRewardReal: Double,
    val rewardMultiplier: Double,
    val rewardMultiplierDisplay: String
)
