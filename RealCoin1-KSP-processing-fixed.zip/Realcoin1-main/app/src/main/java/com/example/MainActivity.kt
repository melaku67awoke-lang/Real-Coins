package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.ui.screens.MainAppScaffold
import com.example.ui.screens.OnboardingFlow
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import com.example.ui.theme.CryptoDarkBg
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.RealCoinViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: RealCoinViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val user by viewModel.user.collectAsState()
                var onboardingComplete by remember { androidx.compose.runtime.mutableStateOf(false) }
                Surface(modifier = Modifier.fillMaxSize(), color = CryptoDarkBg) {
                    if (user == null || !onboardingComplete) {
                        OnboardingFlow(viewModel = viewModel, onApproved = { onboardingComplete = true })
                    } else {
                        MainAppScaffold(viewModel = viewModel)
                    }
                }
            }
        }
    }
}

