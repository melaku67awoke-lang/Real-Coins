package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entities.UserEntity
import com.example.ui.theme.CryptoCardBg
import com.example.ui.theme.CryptoDarkBg
import com.example.ui.theme.CryptoGreen
import com.example.ui.theme.RealGoldPrimary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.RealCoinViewModel

@Composable
fun OnboardingFlow(viewModel: RealCoinViewModel, onApproved: () -> Unit) {
    val currentUser by viewModel.user.collectAsState()
    var page by remember { mutableStateOf<String?>(null) }
    androidx.compose.runtime.LaunchedEffect(currentUser?.kycStatus) {
        if (page == null) {
            page = when (currentUser?.kycStatus) {
                "PENDING" -> "waiting"
                "APPROVED" -> { onApproved(); "done" }
                "REJECTED" -> "kyc"
                else -> "landing"
            }
        } else if (currentUser?.kycStatus == "APPROVED") onApproved()
    }
    when (page) {
        "landing" -> LandingScreen(
            onRegister = { page = "register" },
            onLogin = { page = "login" }
        )
        "register" -> RegistrationScreen(
            onBack = { page = "landing" },
            onNext = { nick, name, phone, email, password ->
                viewModel.registerUser(nick, name, phone, email, password) { ok, _ -> if (ok) page = "kyc" }
            }
        )
        "login" -> LoginScreen(
            onBack = { page = "landing" },
            onLogin = { identifier, password ->
                viewModel.loginUser(identifier, password) { ok, _ -> if (ok) page = "done" }
            }
        )
        "kyc" -> KycOnboardingScreen(
            onBack = { page = "register" },
            onSubmit = { type, number, front, back -> viewModel.submitKyc(type, number, front, back); page = "waiting" }
        )
        "waiting" -> KycWaitingScreen(user = currentUser)
        else -> Unit
    }
}

@Composable
private fun LandingScreen(onRegister: () -> Unit, onLogin: () -> Unit) {
    Box(Modifier.fillMaxSize().background(CryptoDarkBg)) {
        Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Card(colors = CardDefaults.cardColors(containerColor = CryptoCardBg), shape = RoundedCornerShape(28.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.VerifiedUser, null, tint = RealGoldPrimary, modifier = Modifier.size(72.dp))
                    Spacer(Modifier.height(18.dp))
                    Text("REAL COIN", color = TextPrimary, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Secure P2P • Escrow • Real Coin Wallet", color = TextSecondary, fontSize = 14.sp)
                    Spacer(Modifier.height(28.dp))
                    Button(onClick = onRegister, modifier = Modifier.fillMaxWidth().height(52.dp), colors = ButtonDefaults.buttonColors(containerColor = RealGoldPrimary)) { Text("Create account", fontWeight = FontWeight.Bold) }
                    Spacer(Modifier.height(12.dp))
                    OutlinedButton(onClick = onLogin, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("Login") }
                    Spacer(Modifier.height(20.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Security, null, tint = CryptoGreen, modifier = Modifier.size(18.dp)); Text("  Identity verification protects your account", color = TextMuted, fontSize = 12.sp) }
                }
            }
        }
    }
}

@Composable
private fun RegistrationScreen(onBack: () -> Unit, onNext: (String,String,String,String,String) -> Unit) {
    var nick by remember { mutableStateOf("") }; var name by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }; var email by remember { mutableStateOf("") }; var password by remember { mutableStateOf("") }; var confirm by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(CryptoDarkBg).verticalScroll(rememberScrollState()).padding(20.dp)) {
        IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back", tint = TextPrimary) }
        Text("Create your account", color = TextPrimary, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("Your nickname is the name other users see in P2P.", color = TextSecondary)
        Spacer(Modifier.height(22.dp))
        OnboardField("Nickname (used for P2P)", nick) { nick = it }
        OnboardField("Name (exactly as National ID)", name) { name = it }
        OnboardField("Phone number", phone) { phone = it }
        OnboardField("Email address", email) { email = it }
        OnboardField("Password", password, true) { password = it }
        OnboardField("Confirm password", confirm, true) { confirm = it }
        Spacer(Modifier.height(12.dp))
        Button(onClick = { if (password == confirm) onNext(nick,name,phone,email,password) }, enabled = nick.isNotBlank() && name.isNotBlank() && phone.isNotBlank() && email.isNotBlank() && password.length >= 8 && password == confirm, modifier = Modifier.fillMaxWidth().height(52.dp), colors = ButtonDefaults.buttonColors(containerColor = RealGoldPrimary)) { Text("Continue to KYC") }
    }
}

@Composable
private fun LoginScreen(onBack: () -> Unit, onLogin: (String,String) -> Unit) {
    var identifier by remember { mutableStateOf("") }; var password by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(CryptoDarkBg).padding(20.dp)) {
        IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back", tint = TextPrimary) }
        Spacer(Modifier.height(30.dp)); Text("Welcome back", color = TextPrimary, fontSize = 28.sp, fontWeight = FontWeight.Bold); Text("Login with your email or P2P nickname.", color = TextSecondary)
        Spacer(Modifier.height(24.dp)); OnboardField("Email or nickname", identifier) { identifier = it }; OnboardField("Password", password, true) { password = it }
        Spacer(Modifier.height(12.dp)); Button(onClick = { onLogin(identifier,password) }, enabled = identifier.isNotBlank() && password.isNotBlank(), modifier = Modifier.fillMaxWidth().height(52.dp), colors = ButtonDefaults.buttonColors(containerColor = RealGoldPrimary)) { Text("Login") }
    }
}

@Composable
private fun KycOnboardingScreen(onBack: () -> Unit, onSubmit: (String,String,String,String) -> Unit) {
    var type by remember { mutableStateOf("National ID") }; var expanded by remember { mutableStateOf(false) }; var number by remember { mutableStateOf("") }; var front by remember { mutableStateOf<String?>(null) }; var back by remember { mutableStateOf<String?>(null) }
    val frontPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { it?.let { front = it.toString() } }
    val backPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { it?.let { back = it.toString() } }
    Column(Modifier.fillMaxSize().background(CryptoDarkBg).verticalScroll(rememberScrollState()).padding(20.dp)) {
        IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back", tint = TextPrimary) }
        Text("Identity verification", color = TextPrimary, fontSize = 28.sp, fontWeight = FontWeight.Bold); Text("Select your ID and upload both sides from your gallery.", color = TextSecondary)
        Spacer(Modifier.height(20.dp))
        Text("ID type", color = TextSecondary); Box { OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(type, color = TextPrimary) }; DropdownMenu(expanded = expanded, onDismissRequest = { expanded=false }) { listOf("National ID","Passport","Driver License").forEach { option -> DropdownMenuItem(text={Text(option)}, onClick={type=option; expanded=false}) } } }
        OnboardField("ID number", number) { number = it }
        UploadCard("ID front", front != null) { frontPicker.launch("image/*") }
        UploadCard("ID back", back != null) { backPicker.launch("image/*") }
        Spacer(Modifier.height(12.dp)); Button(onClick={onSubmit(type,number,front!!,back!!)}, enabled=number.isNotBlank() && front != null && back != null, modifier=Modifier.fillMaxWidth().height(52.dp), colors=ButtonDefaults.buttonColors(containerColor=RealGoldPrimary)) { Text("Submit KYC") }
    }
}

@Composable
private fun UploadCard(title: String, uploaded: Boolean, onClick: () -> Unit) { Card(Modifier.fillMaxWidth().padding(vertical=7.dp).clickable(onClick=onClick), colors=CardDefaults.cardColors(containerColor=CryptoCardBg), shape=RoundedCornerShape(16.dp)) { Row(Modifier.padding(18.dp), verticalAlignment=Alignment.CenterVertically) { Icon(if(uploaded) Icons.Default.CheckCircle else Icons.Default.CloudUpload,null,tint=if(uploaded) CryptoGreen else RealGoldPrimary); Column(Modifier.padding(start=14.dp)) { Text(title,color=TextPrimary,fontWeight=FontWeight.Bold); Text(if(uploaded) "Selected from gallery" else "Tap to choose image",color=TextSecondary,fontSize=12.sp) } } } }

@Composable
private fun KycWaitingScreen(user: UserEntity?) { Box(Modifier.fillMaxSize().background(CryptoDarkBg), contentAlignment=Alignment.Center) { Card(Modifier.fillMaxWidth().padding(24.dp), colors=CardDefaults.cardColors(containerColor=CryptoCardBg), shape=RoundedCornerShape(24.dp)) { Column(Modifier.padding(28.dp), horizontalAlignment=Alignment.CenterHorizontally) { Icon(Icons.Default.Lock,null,tint=RealGoldPrimary,modifier=Modifier.size(64.dp)); Spacer(Modifier.height(18.dp)); Text("KYC submitted successfully",color=TextPrimary,fontSize=23.sp,fontWeight=FontWeight.Bold); Spacer(Modifier.height(8.dp)); Text("Please wait for Admin approval. You will enter the main app automatically after your KYC is approved.",color=TextSecondary,textAlign=androidx.compose.ui.text.style.TextAlign.Center); Spacer(Modifier.height(18.dp)); Text("Status: ${user?.kycStatus ?: "PENDING"}",color=RealGoldPrimary,fontWeight=FontWeight.Bold) } } } }

@Composable
private fun OnboardField(label: String, value: String, password: Boolean = false, onChange: (String)->Unit) { OutlinedTextField(value=value,onValueChange=onChange,label={Text(label)},singleLine=true,visualTransformation=if(password) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,modifier=Modifier.fillMaxWidth().padding(vertical=6.dp)) }
