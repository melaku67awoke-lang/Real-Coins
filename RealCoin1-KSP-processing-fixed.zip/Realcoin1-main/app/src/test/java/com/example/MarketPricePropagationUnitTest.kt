package com.example

import org.junit.Assert.assertEquals
import org.junit.Test

class MarketPricePropagationUnitTest {
    @Test
    fun p2pEtbPriceUsesLatestMarketRate() {
        val usdRate = 0.01
        val usdToEtb = 186.0
        assertEquals(1.86, usdRate * usdToEtb, 0.000001)
    }

    @Test
    fun withdrawalUsdValueUsesLatestMarketRate() {
        val realAmount = 1000.0
        val usdRate = 0.01
        assertEquals(10.0, realAmount * usdRate, 0.000001)
    }

    @Test
    fun depositRealAmountUsesLatestMarketRateAndTenPercentBonus() {
        val usdAmount = 25.0
        val usdRate = 0.01
        val base = usdAmount / usdRate
        val total = base * 1.10
        assertEquals(2750.0, total, 0.000001)
    }
}
