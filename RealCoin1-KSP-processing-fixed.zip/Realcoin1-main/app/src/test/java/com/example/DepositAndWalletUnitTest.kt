package com.example

import com.example.data.local.entities.DepositRequestEntity
import com.example.data.local.entities.MarketRateEntity
import com.example.data.local.entities.UserEntity
import com.example.ui.viewmodel.NotificationType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DepositAndWalletUnitTest {

    @Test
    fun testBep20AddressFormat() {
        val bep20Address = "0x8e54105bed3243e1ca44a0cccc6b62cf2bff9df4"
        assertTrue("BEP-20 address must start with 0x", bep20Address.startsWith("0x"))
        assertEquals("BEP-20 address must be 42 characters long", 42, bep20Address.length)
        assertTrue(
            "BEP-20 address must be hex characters",
            bep20Address.removePrefix("0x").all { it in "0123456789abcdefABCDEF" }
        )
    }

    @Test
    fun testDepositBonusCalculation() {
        val usdtDeposit = 100.0
        val usdRate = 0.0027
        val baseRealCoin = usdtDeposit / usdRate
        val bonusPercent = 0.10 // 10% bonus
        val bonusRealCoin = baseRealCoin * bonusPercent
        val totalRealCoin = baseRealCoin + bonusRealCoin

        assertEquals(37037.04, baseRealCoin, 0.01)
        assertEquals(3703.70, bonusRealCoin, 0.01)
        assertEquals(40740.74, totalRealCoin, 0.02)
    }

    @Test
    fun testDepositRequestEntityDefaults() {
        val depositReq = DepositRequestEntity(
            id = "dep_test_01",
            userId = "hab_user_01",
            username = "hab",
            amountUsd = 50.0,
            network = "BSC (BNB Smart Chain BEP20)",
            depositAddress = "0x8e54105bed3243e1ca44a0cccc6b62cf2bff9df4",
            baseRealCoin = 590.08,
            bonusRealCoin = 59.008,
            totalRealCoin = 649.088
        )

        assertEquals("BSC (BNB Smart Chain BEP20)", depositReq.network)
        assertEquals("0x8e54105bed3243e1ca44a0cccc6b62cf2bff9df4", depositReq.depositAddress)
        assertEquals("PENDING", depositReq.status)
        assertTrue(depositReq.totalRealCoin > depositReq.baseRealCoin)
    }

    @Test
    fun testMinimumDepositThreshold() {
        val minDepositAllowed = 25.0
        val testDepositLow = 20.0
        val testDepositValid = 25.0
        val testDepositHigh = 100.0

        assertTrue("Deposit below $25 must be rejected", testDepositLow < minDepositAllowed)
        assertTrue("Deposit of $25 must be accepted", testDepositValid >= minDepositAllowed)
        assertTrue("Deposit of $100 must be accepted", testDepositHigh >= minDepositAllowed)
    }

    @Test
    fun testSpinWheelPrizeMultipliers() {
        val spinPrizes = listOf(5.0, 10.0, 15.0, 20.0, 25.0, 50.0, 100.0, 200.0)
        assertTrue(spinPrizes.isNotEmpty())
        for (prize in spinPrizes) {
            assertTrue("Prize must be greater than zero", prize > 0.0)
        }
        val minPrize = spinPrizes.minOrNull() ?: 0.0
        val maxPrize = spinPrizes.maxOrNull() ?: 0.0
        assertEquals(5.0, minPrize, 0.001)
        assertEquals(200.0, maxPrize, 0.001)
    }

    @Test
    fun testUserLevelTiersAndDailyRewards() {
        assertEquals("Starter", com.example.data.model.UserLevelTier.getTierForDeposit(0.0).levelName)
        assertEquals(10.0, com.example.data.model.UserLevelTier.getDailyRewardForDeposit(0.0), 0.001)
        assertEquals(10.0, com.example.data.model.UserLevelTier.getDailyRewardForDeposit(99.99), 0.001)

        assertEquals("Starter", com.example.data.model.UserLevelTier.getTierForDeposit(100.0).levelName)
        assertEquals("Silver", com.example.data.model.UserLevelTier.getTierForDeposit(150.0).levelName)
        assertEquals("Bronze", com.example.data.model.UserLevelTier.getTierForDeposit(200.0).levelName)
        assertEquals("Gold", com.example.data.model.UserLevelTier.getTierForDeposit(250.0).levelName)
        assertEquals("Diamond", com.example.data.model.UserLevelTier.getTierForDeposit(300.0).levelName)
        assertEquals("Diamond", com.example.data.model.UserLevelTier.getTierForDeposit(1000.0).levelName)

        assertEquals(30.0, com.example.data.model.UserLevelTier.getDailyRewardForDeposit(100.0), 0.001)
        assertEquals(50.0, com.example.data.model.UserLevelTier.getDailyRewardForDeposit(150.0), 0.001)
        assertEquals(75.0, com.example.data.model.UserLevelTier.getDailyRewardForDeposit(200.0), 0.001)
        assertEquals(100.0, com.example.data.model.UserLevelTier.getDailyRewardForDeposit(250.0), 0.001)
        assertEquals(150.0, com.example.data.model.UserLevelTier.getDailyRewardForDeposit(300.0), 0.001)
    }

    @Test
    fun testDepositLevelProgress() {
        val beforeStarter = com.example.data.model.UserLevelTier.calculateProgress(50.0)
        assertEquals(0.5f, beforeStarter.progressToNextTier, 0.001f)
        assertEquals(50.0, beforeStarter.amountNeededForNextTier, 0.001)

        val silverProgress = com.example.data.model.UserLevelTier.calculateProgress(125.0)
        assertEquals("Starter", silverProgress.currentTier.levelName)
        assertEquals("Silver", silverProgress.nextTier?.levelName)
        assertEquals(0.5f, silverProgress.progressToNextTier, 0.001f)
        assertEquals(25.0, silverProgress.amountNeededForNextTier, 0.001)

        val diamond = com.example.data.model.UserLevelTier.calculateProgress(300.0)
        assertEquals("Diamond", diamond.currentTier.levelName)
        assertEquals(null, diamond.nextTier)
        assertEquals(1.0f, diamond.progressToNextTier, 0.001f)
        assertEquals(150.0, diamond.dailyRewardReal, 0.001)
    }

    @Test
    fun testDailyRewardTwentyFourHourCooldown() {
        val cooldown = 24 * 60 * 60 * 1000L
        val now = 2 * cooldown
        assertTrue("Reward is locked before 24 hours", now - (now - cooldown + 1) < cooldown)
        assertTrue("Reward is available at 24 hours", now - (now - cooldown) >= cooldown)
    }

    @Test
    fun testNotificationTypes() {
        val successType = NotificationType.SUCCESS
        val errorType = NotificationType.ERROR
        val warningType = NotificationType.WARNING
        val infoType = NotificationType.INFO

        assertNotNull(successType)
        assertNotNull(errorType)
        assertNotNull(warningType)
        assertNotNull(infoType)
    }

    @Test
    fun todayMarketPriceIs0027UsdPerReal() {
        val realToUsd = 0.0027
        val usdToEtb = 186.0
        assertEquals(0.0027, realToUsd, 0.0000001)
        assertEquals(0.5022, realToUsd * usdToEtb, 0.000001)
    }

    @Test
    fun dashboardBalanceUsesMarketPriceForUsdAndEtb() {
        val balance = 1000.0
        val usd = balance * 0.0027
        val etb = usd * 186.0
        assertEquals(2.70, usd, 0.000001)
        assertEquals(502.20, etb, 0.000001)
    }

    @Test
    fun administratorCanIncreaseMarketPriceWithoutUpperLimit() {
        val current = 0.0027
        val increased = 0.0050
        assertTrue(increased > current)
        assertTrue(increased.isFinite())
        assertTrue(increased > 0.0)
    }
}
