# RealCoin KSP / GitHub Actions build fix

- Kotlin remains 2.2.10.
- KSP changed from 2.3.5 to 2.2.10-2.0.2 so it matches Kotlin 2.2.10.
- KSP2 is explicitly enabled.
- The custom debug.keystore requirement was removed; debug builds use the Android Gradle Plugin's standard debug signing.
- GitHub Actions installs Android API 36.1 and Build Tools 36.1.0 to match compileSdk 36.1.
- Build uses Gradle 9.3.1 and JDK 17.
