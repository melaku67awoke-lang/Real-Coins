Cloudflare build trigger
