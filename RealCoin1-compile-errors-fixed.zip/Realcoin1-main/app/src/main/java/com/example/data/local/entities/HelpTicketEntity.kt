package com.example.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "help_tickets")
data class HelpTicketEntity(
    @PrimaryKey var ticketId: String,
    var category: String, // "Deposit/Withdraw", "P2P & Escrow", "KYC", "Spin Game", "Other"
    var subject: String,
    var message: String,
    var imageUri: String? = null,
    var status: String = "OPEN", // "OPEN", "ANSWERED", "RESOLVED"
    var adminReply: String? = null,
    var timestamp: Long = System.currentTimeMillis()
)
