package com.example.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "posts")
data class PostEntity(
    @PrimaryKey var postId: String,
    var authorUsername: String,
    var authorLevel: String = "Starter",
    var contentText: String,
    var mediaType: String, // "IMAGE", "VIDEO_SHORT"
    var mediaUrl: String = "",
    var durationSeconds: Int = 15,
    var likesCount: Int = 0,
    var commentsCount: Int = 0,
    var isLiked: Boolean = false,
    var timestamp: Long = System.currentTimeMillis()
)
