package com.example.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "wallet_transactions")
data class WalletTransactionEntity(
    @PrimaryKey var txId: String,
    var type: String, // "DEPOSIT_USDT", "WITHDRAW_USDT", "P2P_BUY", "P2P_SELL", "DAILY_REWARD", "SPIN_WIN", "SPIN_BET"
    var title: String,
    var amountReal: Double,
    var bonusReal: Double = 0.0,
    var amountUsdt: Double = 0.0,
    var amountEtb: Double = 0.0,
    var isPositive: Boolean = true,
    var status: String = "Completed",
    var timestamp: Long = System.currentTimeMillis()
)
