package com.example.data.local.entities

import androidx.room.Entity
import androidx.room.Ignore
import androidx.room.PrimaryKey

@Entity(tableName = "market_rates")
data class MarketRateEntity(
    @PrimaryKey var id: Int = 1,
    var coinSymbol: String = "REAL",
    var realCoinToUsd: Double = 0.0027,
    var usdToEtb: Double = 186.0,
    var dailyGrowthPct: Double = 0.4,
    var dailyRange: String = "0.3% - 9%",
    var monthlyRange: String = "52% - 165%",
    var yearlyRange: String = "725% - 2345%",
    var lastUpdated: Long = System.currentTimeMillis()
) {
    @get:Ignore
    var realCoinToEtb: Double
        get() = realCoinToUsd * usdToEtb
}
