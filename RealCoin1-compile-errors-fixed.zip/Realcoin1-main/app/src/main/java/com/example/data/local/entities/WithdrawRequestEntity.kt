package com.example.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "withdraw_requests")
data class WithdrawRequestEntity(
    @PrimaryKey var id: String = "wth_req_${System.currentTimeMillis()}",
    var userId: String = "hab_user_01",
    var username: String = "hab",
    var amountReal: Double,
    var amountUsdt: Double,
    var destinationAddress: String,
    var network: String = "BSC (BNB Smart Chain BEP20)",
    var status: String = "PENDING", // "PENDING", "APPROVED", "REJECTED"
    var adminTxHash: String? = null,
    var adminNote: String? = null,
    var timestamp: Long = System.currentTimeMillis(),
    var processedTimestamp: Long? = null
)
