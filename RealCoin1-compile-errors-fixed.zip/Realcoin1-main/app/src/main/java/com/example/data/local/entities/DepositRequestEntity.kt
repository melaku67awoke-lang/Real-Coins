package com.example.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "deposit_requests")
data class DepositRequestEntity(
    @PrimaryKey var id: String = "dep_req_${System.currentTimeMillis()}",
    var userId: String = "hab_user_01",
    var username: String = "hab",
    var amountUsd: Double,
    var network: String = "BSC (BNB Smart Chain BEP20)",
    var depositAddress: String = "0x8e54105bed3243e1ca44a0cccc6b62cf2bff9df4",
    var baseRealCoin: Double,
    var bonusRealCoin: Double, // 10% bonus
    var totalRealCoin: Double, // base + bonus
    var screenshotUri: String? = null,
    var txHash: String? = null,
    var status: String = "PENDING", // "PENDING", "APPROVED", "REJECTED"
    var adminNote: String? = null,
    var timestamp: Long = System.currentTimeMillis(),
    var processedTimestamp: Long? = null
)
