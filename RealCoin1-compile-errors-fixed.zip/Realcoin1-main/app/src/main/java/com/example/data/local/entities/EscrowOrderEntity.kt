package com.example.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "escrow_orders")
data class EscrowOrderEntity(
    @PrimaryKey var orderId: String = "",
    var adId: String,
    var buyerId: String,
    var buyerUsername: String,
    var sellerId: String,
    var sellerUsername: String,
    var type: String = "BUY", // "BUY" or "SELL" from creator perspective
    var realAmount: Double,
    var giftRealAmount: Double = 0.0,
    var pricePerCoinEtb: Double,
    var totalEtb: Double,
    var paymentMethod: String = "Telebirr",
    var paymentAccountDetails: String = "",
    var status: String, // "PENDING_PAYMENT", "PAID_WAITING_RELEASE", "COMPLETED", "DISPUTED", "CANCELLED"
    var disputeReason: String? = null,
    var disputeEvidence: String? = null,
    var createdAt: Long = System.currentTimeMillis(),
    var completedAt: Long? = null
)
