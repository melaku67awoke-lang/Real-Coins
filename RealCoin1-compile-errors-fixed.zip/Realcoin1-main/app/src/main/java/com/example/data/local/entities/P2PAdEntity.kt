package com.example.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "p2p_ads")
data class P2PAdEntity(
    @PrimaryKey var id: String,
    var userId: String,
    var username: String,
    var userLevel: String = "Starter",
    var type: String, // "BUY" or "SELL"
    var priceEtb: Double,
    var minReal: Double,
    var maxReal: Double,
    var giftReal: Double = 0.0,
    var paymentMethods: String, // selected Ethiopian payment method
    var paymentAccountDetails: String = "",
    var completionRate: Int = 100,
    var completedOrders: Int = 12,
    var lastSeenText: String = "Online",
    var status: String = "ACTIVE",
    var createdAt: Long = System.currentTimeMillis()
)
