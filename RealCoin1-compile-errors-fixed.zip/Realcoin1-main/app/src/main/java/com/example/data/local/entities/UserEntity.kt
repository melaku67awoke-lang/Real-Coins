package com.example.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey var userId: String = "usr_main_01",
    var username: String = "Fikeru",
    var passwordHash: String? = null,
    var fullName: String = "Fikeru Kebede",
    var email: String = "fikerukebede16@gmail.com",
    var phone: String = "+251911000000",
    var walletAddress: String = "",
    var country: String = "Ethiopia",
    var joinedDate: String = "04/08/2026",
    var avatarUrl: String = "",
    var realCoinBalance: Double = 0.0,
    var holdBalance: Double = 0.0,
    var usdtDepositTotal: Double = 45.0,
    var level: String = "Starter",
    var kycStatus: String = "APPROVED", // NOT_SUBMITTED, PENDING, APPROVED, REJECTED
    var kycIdFrontUri: String? = null,
    var kycIdBackUri: String? = null,
    var kycDocumentNumber: String? = null,
    var kycDocumentType: String? = null,
    var paymentBank: String? = null,
    var paymentAccountNumber: String? = null,
    var lastDailyRewardTimestamp: Long = 0L,
    var lastFreeSpinTimestamp: Long = 0L,
    var isCreator: Boolean = true,
    var isAdmin: Boolean = false
)
