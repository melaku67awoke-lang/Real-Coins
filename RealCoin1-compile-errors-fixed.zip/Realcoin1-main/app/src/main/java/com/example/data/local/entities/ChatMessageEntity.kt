package com.example.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey var messageId: String,
    var senderUsername: String,
    var receiverUsername: String,
    var text: String,
    var timestamp: Long = System.currentTimeMillis(),
    var isFromMe: Boolean = false,
    var orderId: String? = null,
    var senderRole: String = "USER" // "USER", "COUNTERPARTY", "SYSTEM", "ARBITRATOR"
)
